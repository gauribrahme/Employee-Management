import { Component, OnInit,Input } from '@angular/core';
import { SharedService } from 'src/app/shared.service';


@Component({
  selector: 'app-show-proj',
  templateUrl: './show-proj.component.html',
  styleUrls: ['./show-proj.component.css']
})
export class ShowProjComponent implements OnInit {

  constructor(private service:SharedService) { }

  ProjectList:any=[];

  ModalTitle!: string;
  ActivateAddEditProjComp:boolean=false;
  proj:any;

  ProjectIdFilter:string="";
  ProjectNameFilter:string="";
  ProjectListWithoutFilter:any=[];

  ngOnInit(): void {
    this.refreshProjList();
  }

  addClick(){
    this.proj={
      ProjectId:0,
      ProjectName:""
    }
    this.ModalTitle="Add Project";
    this.ActivateAddEditProjComp=true;
    //this.ActivateAddEditProjComp=false;
    //this.refreshProjList();
  }

  editClick(item: any){
    this.proj=item;
    this.ModalTitle="Edit Project";
    this.ActivateAddEditProjComp=true;
  }

  deleteClick(item: any){
    if(confirm('Are you sure?')){
      this.service.deleteProject(item.ProjectId).subscribe(data=>{
        alert(data.toString());
        this.refreshProjList();
      })
    }
  }
  closeClick(){
    this.ActivateAddEditProjComp=false;
    this.refreshProjList();
  }

  refreshProjList(){
    this.service.getProjList().subscribe(data=>{
      this.ProjectList=data;
      this.ProjectListWithoutFilter=data;
    });
  }

  FilterFn(){
    var ProjectIdFilter = this.ProjectIdFilter;
    var ProjectNameFilter = this.ProjectNameFilter;

    this.ProjectList = this.ProjectListWithoutFilter.filter(function (el:any){
        return el.DepartmentId.toString().toLowerCase().includes(
          ProjectIdFilter.toString().trim().toLowerCase()
        )&&
        el.ProjectName.toString().toLowerCase().includes(
          ProjectNameFilter.toString().trim().toLowerCase()
        )
    });
  }

  sortResult(prop:any,asc:any){
    this.ProjectList = this.ProjectListWithoutFilter.sort(function(a:any,b:any){
      if(asc){
          return (a[prop]>b[prop])?1 : ((a[prop]<b[prop]) ?-1 :0);
      }else{
        return (b[prop]>a[prop])?1 : ((b[prop]<a[prop]) ?-1 :0);
      }
    })
  }


}
