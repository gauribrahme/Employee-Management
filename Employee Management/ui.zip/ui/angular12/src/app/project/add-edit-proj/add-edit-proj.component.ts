import { Component, OnInit,Input } from '@angular/core';
import { SharedService } from 'src/app/shared.service';

@Component({
  selector: 'app-add-edit-proj',
  templateUrl: './add-edit-proj.component.html',
  styleUrls: ['./add-edit-proj.component.css']
})

export class AddEditProjComponent implements OnInit {

  constructor(private service:SharedService) { }


  @Input() proj:any;
  ProjectId!: string;
  ProjectName!: string;

  ngOnInit(): void {
    this.ProjectId=this.proj.ProjectId;
    this.ProjectName=this.proj.ProjectName;
  }

  addProject(){
    var val = {ProjectId:this.ProjectId,
    ProjectName:this.ProjectName};
    this.service.addProject(val).subscribe(res=>{
      alert(res.toString());
    })
  }

  updateProject(){
    var val = {ProjectId:this.ProjectId,
      ProjectName:this.ProjectName};
      this.service.updateProject(val).subscribe(res=>{
        alert(res.toString());
      })
  }

}
